/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Xe;

import java.util.Date;

/**
 *
 * @author DELL
 */
public class KhuyenMai {
    private String makm;
    private String tenkm;
    private String loaikm;
    private int soluong;
    private Date batdau;
    private Date ketthuc;
    private int phantram;
private String hinh;

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }

    public int getPhantram() {
        return phantram;
    }

    public void setPhantram(int phantram) {
        this.phantram = phantram;
    }

    /**
     *
     * @return
     */
    
    public String getMakm() {
        return makm;
    }

    public void setMakm(String makm) {
        this.makm = makm;
    }

    public String getTenkm() {
        return tenkm;
    }

    public void setTenkm(String tenkm) {
        this.tenkm = tenkm;
    }

    public String getLoaikm() {
        return loaikm;
    }

    public void setLoaikm(String loaikm) {
        this.loaikm = loaikm;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public Date getBatdau() {
        return batdau;
    }

    public void setBatdau(Date batdau) {
        this.batdau = batdau;
    }

    public Date getKetthuc() {
        return ketthuc;
    }

    public void setKetthuc(Date ketthuc) {
        this.ketthuc = ketthuc;
    }
    
    
}
