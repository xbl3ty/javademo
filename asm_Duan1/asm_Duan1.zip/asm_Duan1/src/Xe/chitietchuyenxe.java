/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Xe;

/**
 *
 * @author DELL
 */
public class chitietchuyenxe {
    private String mactcx;
    private int sove;
    private String diemdon;
    private String diemden;
    private String kigui;
    private String phuongthucthanhtoan;
    private String makm;
    private String mand;
    private String maxe;
    private int gia;

    public String getMaxe() {
        return maxe;
    }

    public void setMaxe(String maxe) {
        this.maxe = maxe;
    }

    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public String getMactcx() {
        return mactcx;
    }

    public void setMactcx(String mactcx) {
        this.mactcx = mactcx;
    }

    public int getSove() {
        return sove;
    }

    public void setSove(int sove) {
        this.sove = sove;
    }

    public String getDiemdon() {
        return diemdon;
    }

    public void setDiemdon(String diemdon) {
        this.diemdon = diemdon;
    }

    public String getDiemden() {
        return diemden;
    }

    public void setDiemden(String diemden) {
        this.diemden = diemden;
    }

    public String getKigui() {
        return kigui;
    }

    public void setKigui(String kigui) {
        this.kigui = kigui;
    }

    public String getPhuongthucthanhtoan() {
        return phuongthucthanhtoan;
    }

    public void setPhuongthucthanhtoan(String phuongthucthanhtoan) {
        this.phuongthucthanhtoan = phuongthucthanhtoan;
    }

    public String getMakm() {
        return makm;
    }

    public void setMakm(String makm) {
        this.makm = makm;
    }

    public String getMand() {
        return mand;
    }

    public void setMand(String mand) {
        this.mand = mand;
    }
    
}
