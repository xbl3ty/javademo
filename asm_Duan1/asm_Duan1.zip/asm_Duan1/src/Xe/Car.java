/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Xe;

/**
 *
 * @author DELL
 */
public class Car {
    private String Macx;
    private int Manv;
    private String Diemdon;
    private String Diemden;
    private int Trangthai;
    private String Thoigianxuatphat;
    private String Biensoxe;
    private int gia;
    private String vechuaban;
    private String vedaban;

    public String getVechuaban() {
        return vechuaban;
    }

    public void setVechuaban(String vechuaban) {
        this.vechuaban = vechuaban;
    }

    public String getVedaban() {
        return vedaban;
    }

    public void setVedaban(String vedaban) {
        this.vedaban = vedaban;
    }
    
    public String getMacx() {
        return Macx;
    }

    public void setMacx(String Macx) {
        this.Macx = Macx;
    }

    public int getManv() {
        return Manv;
    }

    public void setManv(int Manv) {
        this.Manv = Manv;
    }

    public String getDiemdon() {
        return Diemdon;
    }

    public void setDiemdon(String Diemdon) {
        this.Diemdon = Diemdon;
    }

    public String getDiemden() {
        return Diemden;
    }

    public void setDiemden(String Diemden) {
        this.Diemden = Diemden;
    }

    public int isTrangthai() {
        return Trangthai;
    }

    public void setTrangthai(int Trangthai) {
        this.Trangthai = Trangthai;
    }

    public String getThoigianxuatphat() {
        return Thoigianxuatphat;
    }

    public void setThoigianxuatphat(String Thoigianxuatphat) {
        this.Thoigianxuatphat = Thoigianxuatphat;
    }

    public String getBiensoxe() {
        return Biensoxe;
    }

    public void setBiensoxe(String Biensoxe) {
        this.Biensoxe = Biensoxe;
    }

    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

}